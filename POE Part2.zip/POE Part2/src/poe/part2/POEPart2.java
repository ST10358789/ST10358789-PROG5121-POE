package poe.part2;

public class POEPart2 {
  
    public static void main(String[] args) {
        Menu.User();
    }
}
